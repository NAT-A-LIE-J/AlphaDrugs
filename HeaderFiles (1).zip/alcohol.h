#include "header.h"
#include "./header.h"
#pragma once
#include <string>

class Alcohol : public Substance
{
public:
    Alcohol();
    Alcohol(std::string n, std::string effects, int quantity){} 

            bool didoverdose() override;

};
