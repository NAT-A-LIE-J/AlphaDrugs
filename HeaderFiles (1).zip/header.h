/**
 * Sample API for <MY_CLASS>
Substance Abuse Tracker 


Base Class: Substance  (attributes: name, ; virtual method: side effect()) ; quantity)


Derived Classes: Types of substances 
-weed
-adderall
-alcohol
-cocaine
Polymorphic behavior: Different types of side effects 
 */

#ifndef MY_CLASS
#define MY_CLASS
#include <string>

class Substance
{
     
public:
    Substance() : name(), sideEffects(), quantity(), unit() {}
    Substance(std::string dName, std::string dEffects, int dQuantity, std::string dUnit) : name(dName), sideEffects(dEffects), quantity(dQuantity), unit(dUnit){} 
    ~Substance() {}
     std::string get_name() const;
     std::string get_effects() const;
     std::string get_unit() const;
    void set_quantity(int q);
    int get_quantity() const; // getter for 
   virtual bool didoverdose() =0; // pure virtual 
    void print_info() const;

protected:
    std::string unit;
    int quantity;
    std::string name;
    std::string sideEffects;
    bool overdose;
};

/* in new files 
class Weed : private Substance
{
public:
    Weed(){}
    Weed(string n; string effects; int quantity){} 
};

class Adderall : private Substance
{
public:
    Adderall(){}
    Adderall(string n; string effects; int quantity){} 
};

class Alcohol : private Substance
{
public:
    Alcohol(){}
    Alcohol(string n; string effects; int quantity){} 
};

class Cocaine : private Substance
{
public:
    Cocaine(){}
    Cocaine(string n; string effects; int quantity){} 
};
*/
#endif 
