#include "./header.h"
#pragma once
#include <string>

#include "header.h"

class Weed : public Substance
{
public:
    Weed();
    Weed(std::string n, std::string effects, int quantity){} 
   
    bool didoverdose() override;

};
