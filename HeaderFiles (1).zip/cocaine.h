#include "header.h"
#include "./header.h"
#pragma once
#include <string>

class Cocaine : public Substance
{
public:
    Cocaine();
    Cocaine(std::string n, std::string effects, int quantity){} 

            bool didoverdose() override;

};
