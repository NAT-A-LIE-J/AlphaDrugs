#include "header.h"
#include "./header.h"
#pragma once
#include <string>

class Adderall : public Substance
{
public:
    Adderall();
    Adderall(std::string n, std::string effects, int quantity){} 

        bool didoverdose() override;

};
