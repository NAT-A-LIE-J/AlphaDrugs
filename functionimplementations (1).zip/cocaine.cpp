#include "../HeaderFiles/header.h"
#include "../HeaderFiles/cocaine.h"
#include <iostream>
#include <string>

Cocaine::Cocaine() : Substance(){
    name = "Cocaine";
    sideEffects = "euphoria, clear thinking, confident, social, and energized.";
    quantity = 0;
    unit = "miligrams";
}



bool Cocaine::didoverdose(){
   if(quantity>119){ return true;}
   else{return false;}
}

