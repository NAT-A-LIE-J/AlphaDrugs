#include "../HeaderFiles/header.h"
#include <iostream>
#include <string>

//print info
void Substance::print_info() const
{  
   std::cout << name << "is a drug with the effects of " << sideEffects << " & with your doses of" << quantity <<" "<< unit << "you overdosed." <<std::endl;
}


//return name
std::string Substance::get_name() const {
  return name;
}
  //return side effects
std::string Substance::get_effects() const {
  return sideEffects;
}

std::string Substance::get_unit() const {
  return unit;
}

  void Substance::set_quantity(int q){
    quantity = q;
  }



