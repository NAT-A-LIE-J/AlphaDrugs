#include "../HeaderFiles/header.h"
#include "../HeaderFiles/adderall.h"
#include <iostream>
#include <string>

Adderall::Adderall() : Substance(){
    name = "Adderall";
    sideEffects = "increased focus, concentration, and motivation.";
    quantity = 0;
    unit = "milligrams";
}



bool Adderall::didoverdose(){
   if(quantity>24){ return true;}
   else{return false;}
}

