#include "../HeaderFiles/header.h"
#include "../HeaderFiles/weed.h"
#include <iostream>
#include <string>

Weed::Weed() : Substance(){
    name = "Weed";
    sideEffects = "altered time perception, impaired thinking, memory, and body movement.";
    quantity = 0;
    unit = "milligrams";
}



bool Weed::didoverdose(){
   if(quantity>80){ return true;}
   else{return false;}
}


