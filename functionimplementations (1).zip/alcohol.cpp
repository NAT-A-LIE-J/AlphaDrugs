#include "../HeaderFiles/header.h"
#include "../HeaderFiles/alcohol.h"
#include <iostream>
#include <string>


Alcohol::Alcohol() : Substance(){
    name = "Alcohol";
    sideEffects = "euphoria, reduced inhibition, drowsy, and relaxed.";
    quantity = 0;
    unit = "shots";
}



bool Alcohol::didoverdose(){
   if(quantity>15){ return true;}
   else{return false;}
}

